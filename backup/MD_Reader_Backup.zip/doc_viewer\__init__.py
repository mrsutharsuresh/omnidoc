"""
Markdown Documentation Viewer
A professional, lightweight web-based markdown documentation viewer.
"""

__version__ = '1.4.0'
__author__ = 'Suresh Kumar'
__email__ = 'sureshk6@cisco.com'
__description__ = 'Professional web-based markdown documentation viewer with modern UI'
