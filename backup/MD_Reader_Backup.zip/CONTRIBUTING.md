# Contributing to DocPresent

First off, thank you for considering contributing to DocPresent! It's people like you that make DocPresent such a great tool.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [How Can I Contribute?](#how-can-i-contribute)
- [Development Setup](#development-setup)
- [Coding Standards](#coding-standards)
- [Commit Messages](#commit-messages)
- [Pull Request Process](#pull-request-process)

## Code of Conduct

This project adheres to Cisco's Code of Business Conduct. By participating, you are expected to uphold this code.

## How Can I Contribute?

### Reporting Bugs

Before creating bug reports, please check the issue list as you might find out that you don't need to create one. When you are creating a bug report, please include as many details as possible:

* **Use a clear and descriptive title**
* **Describe the exact steps to reproduce the problem**
* **Provide specific examples** to demonstrate the steps
* **Describe the behavior you observed** and what you expected
* **Include screenshots** if relevant
* **Include your environment details** (OS, Python version, etc.)

### Suggesting Enhancements

Enhancement suggestions are tracked as GitHub issues. When creating an enhancement suggestion, please include:

* **Use a clear and descriptive title**
* **Provide a step-by-step description** of the suggested enhancement
* **Provide specific examples** to demonstrate the steps
* **Describe the current behavior** and **explain which behavior you expected to see instead**
* **Explain why this enhancement would be useful**

### Pull Requests

* Fill in the required template
* Follow the [coding standards](#coding-standards)
* Include screenshots and animated GIFs in your pull request whenever possible
* Document new code based on the [Documentation Styleguide](#documentation-styleguide)
* End all files with a newline

## Development Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd DocPresent
   ```

2. **Create a virtual environment**
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # Windows: .venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   pip install -r requirements-dev.txt  # Development dependencies
   ```

4. **Install in development mode**
   ```bash
   pip install -e .
   ```

5. **Run the application**
   ```bash
   python run.py  # Debug mode ON by default
   # Or use the CLI
   docpresent start --debug
   ```

## Coding Standards

### Python Style Guide

* Follow [PEP 8](https://www.python.org/dev/peps/pep-0008/) style guide
* Use [Black](https://github.com/psf/black) for code formatting (line length: 100)
* Use [Flake8](https://flake8.pycqa.org/) for linting
* Use type hints where appropriate ([PEP 484](https://www.python.org/dev/peps/pep-0484/))

```bash
# Format code
black doc_viewer/

# Lint code
flake8 doc_viewer/
```

### Code Organization

* Keep functions focused and small
* Use descriptive variable and function names
* Add docstrings to all public functions and classes
* Group imports: standard library, third-party, local
* Maximum line length: 100 characters

### Docstring Format

Use Google-style docstrings:

```python
def function_with_types_in_docstring(param1, param2):
    """Example function with types documented in the docstring.

    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        ValueError: If param1 is negative.
    """
```

## Commit Messages

* Use the present tense ("Add feature" not "Added feature")
* Use the imperative mood ("Move cursor to..." not "Moves cursor to...")
* Limit the first line to 72 characters or less
* Reference issues and pull requests liberally after the first line

### Commit Message Format

```
<type>(<scope>): <subject>

<body>

<footer>
```

**Types:**
* **feat**: A new feature
* **fix**: A bug fix
* **docs**: Documentation only changes
* **style**: Code style changes (formatting, missing semi-colons, etc)
* **refactor**: Code refactoring
* **test**: Adding missing tests
* **chore**: Changes to build process or auxiliary tools

**Example:**
```
feat(toc): Add collapsible sections to table of contents

Implemented collapsible functionality for TOC sections with children.
Users can now click toggle buttons to expand/collapse nested items.

Closes #123
```

## Pull Request Process

1. **Create a feature branch** from `main`
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make your changes** following the coding standards

3. **Add tests** for new functionality

4. **Run tests** to ensure everything passes
   ```bash
   pytest tests/
   ```

5. **Update documentation** if needed
   * Update README.md for user-facing changes
   * Update docstrings for code changes
   * Add entry to CHANGELOG.md

6. **Commit your changes** with descriptive commit messages

7. **Push to your fork** and submit a pull request

8. **Wait for review** - A maintainer will review your PR

### PR Checklist

- [ ] Code follows the project's style guidelines
- [ ] Self-review of code completed
- [ ] Code commented in hard-to-understand areas
- [ ] Documentation updated
- [ ] No new warnings generated
- [ ] Tests added that prove fix is effective or feature works
- [ ] New and existing tests pass locally
- [ ] CHANGELOG.md updated

## Testing

### Running Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=doc_viewer --cov-report=html

# Run specific test file
pytest tests/test_renderer.py

# Run specific test
pytest tests/test_renderer.py::test_markdown_rendering
```

### Writing Tests

* Place tests in the `tests/` directory
* Name test files `test_*.py`
* Name test functions `test_*`
* Use descriptive test names
* Follow AAA pattern (Arrange, Act, Assert)

## Documentation Styleguide

* Use [Markdown](https://guides.github.com/features/mastering-markdown/) for documentation
* Keep line length under 100 characters where possible
* Use code blocks with language identifiers
* Include examples for complex features

## License

By contributing, you agree that your contributions will be licensed under the same license as the project (Cisco Internal Use Only).

## Questions?

Feel free to contact the maintainer:
* Suresh Kumar - sureshk6@cisco.com

Thank you for contributing to DocPresent! 🎉
