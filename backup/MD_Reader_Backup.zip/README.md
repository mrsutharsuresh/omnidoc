# DocPresent - Executive Documentation Platform

**Version 1.0.0** - Professional web-based markdown viewer with vibrant UI, smart diagram conversion, and comprehensive rendering support.

## 🎯 Perfect For

- **SMEs (Subject Matter Experts):** Technical diagrams, SIP flows, network topology
- **Architects:** System diagrams, class diagrams, state machines
- **Managers:** Executive presentations, visual reports, timelines
- **Technical Presentations:** Professional, eye-catching documentation with smart conversions

## ⚡ Quick Start

### Windows (Recommended)
```bash
start.bat
```
This will:
- Check Python installation
- Install dependencies if needed
- Start server on http://localhost:8000
- Automatically open browser

### Direct Python
```bash
python run.py  # Debug mode ON by default
```

### CLI (after installation)
```bash
pip install -e .
md-viewer start
```

## ✨ Key Features

### 📋 Standard Features (Always Active)

These features are **always enabled** for every document:

#### 1. **Smart Heading Normalization**
- Automatically detects and converts various heading formats (ATX, Setext, Title Case)
- Adds consistent anchor IDs to all headings for linking
- Handles numbered headings (1., 2.1, etc.) and Roman numerals (I., II., III.)

#### 2. **Intelligent Table of Contents (TOC)**
- **Universal tree-based algorithm** - Works with any document structure
- **Progressive visual hierarchy** - Font size and indentation based on nesting level
- **Collapsible sections** - Toggle buttons for items with children
- **Clean numbering** - Auto-generated section numbers (1, 1.1, 1.2, 2, 2.1, etc.)
- **Smart text cleanup** - Strips markdown formatting (\*\*bold\*\*, \*italic\*, \`code\`) and numeric prefixes from TOC entries
- **Proper nesting** - Handles H1→H2→H3→H4→H5→H6 hierarchies correctly
- **No duplicate numbering** - Prevents issues with documents having multiple H1/H2 sections
- **Smart positioning** - Appears at top for conversational docs, after H1 for standard docs
- **Code block aware** - Correctly ignores # comments inside code fences

#### 3. **Attribute Sanitization**
- Removes stray `{#anchor}` tags from document body
- Preserves anchor IDs only in headings (processed by attr_list extension)
- Prevents anchor text from appearing in rendered content

#### 4. **Code Block Annotation**
- Detects and annotates code blocks with type markers
- Identifies: programming code, SIP signaling, network topology, flowcharts
- Enables smart conversion features to work intelligently

---

### 🧪 Experimental Features (Smart Toggle)

Toggle with **?smart=true** or **?smart=false** in URL:

#### 1. **SMART_TABLES** - ASCII Table Conversion ✅ *Implemented*
- Converts space-separated ASCII tables to proper Markdown tables
- Detects columns separated by 2+ spaces
- Auto-generates headers and separator lines
- **Status**: Fully functional

#### 2. **SMART_SIP** - SIP Signaling to Mermaid ✅ *Implemented*
- Auto-converts SIP protocol flows to interactive sequence diagrams
- Recognizes: INVITE, ACK, BYE, CANCEL, 100 Trying, 200 OK, etc.
- Context-aware detection (checks heading keywords)
- Excludes programming code (C, Java, Python)
- **Status**: Production-ready with intelligence

#### 3. **SMART_TOPOLOGY** - Network Diagrams 🚧 *Basic Implementation*
- Converts ASCII network diagrams to Mermaid flowcharts
- Detects box-drawing characters: +---, |, ─, │, etc.
- **Status**: Placeholder - needs connection parsing, port mapping, bidirectional flows

---

### 🔮 Future Experimental Features

**Under Consideration:**
- **SMART_CHARTS** - Data tables → Interactive charts (line, bar, pie)
- **SMART_LOGS** - Log file syntax highlighting with severity colors
- **SMART_CONFIG** - Configuration file pretty-printing (XML, JSON, YAML)
- **SMART_CALLFLOW** - Enhanced telecom call flow diagrams
- **SMART_TIMELINE** - Timestamped events → Visual timelines

### 🌈 Vibrant Professional UI
- **Modern Design** with warm neutrals and 3-stop gradients (#6366f1→#8b5cf6→#d946ef)
- **Glassmorphism Effects** with translucent surfaces
- **Light/Dark Themes** with WCAG AAA contrast ratios
- **Responsive Layout** with maximized content width

### 📊 Advanced Markdown Support (19 Extensions)
- **Tables** with gradient headers and hover effects
- **Code Highlighting** with optimized monospace fonts (Cascadia Code)
- **Task Lists, Footnotes, Abbreviations**
- **Admonitions** (note, warning, danger, success)
- **Mathematical Formulas** (KaTeX)
- **Subscript, Superscript, Highlighting**

### 📈 Diagram Support (Mermaid.js)
- **Flowcharts** - Process flows and decision trees
- **Sequence Diagrams** - SIP signaling, API calls, system interactions
- **Class Diagrams** - Object-oriented design
- **State Diagrams** - State machines and workflows
- **Gantt Charts** - Project timelines
- **Pie Charts, Git Graphs, ER Diagrams**

## Installation

1. **Install Python dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Optional: Install as package:**
   ```bash
   pip install -e .
   ```

## Usage

1. **Add your Markdown files:**
   Place your `.md` files in the `markdown_files` folder (auto-created if needed).

2. **Run the application:**
   ```bash
   python run.py
   # or
   start.bat
   # or if installed
   md-viewer start
   ```

3. **View in browser:**
   - Main hub: http://localhost:8000
   - Documentation: http://localhost:8000/docs
   - Advanced demo: http://localhost:8000/file/advanced_features.md

## 📚 Creating Rich Documentation

### Diagrams (Mermaid)
````markdown
```mermaid
flowchart TD
    A[Start] --> B{Decision}
    B -->|Yes| C[Action]
    B -->|No| D[End]
```
````

### Math Formulas (KaTeX)
```markdown
Inline: $E = mc^2$

Block:
$$
\int_{a}^{b} f(x) dx = F(b) - F(a)
$$
```

### Task Lists
```markdown
- [x] Completed task
- [ ] Pending task
```

### Admonitions
```markdown
!!! note "Title"
    Important information here

!!! warning "Caution"
    Warning message

!!! danger "Critical"
    Critical warning
```

See `advanced_features.md` for comprehensive examples!

## CLI Commands

```bash
# Show version
python -m md_viewer.cli --version
md-viewer --version

# Start server (default: localhost:8000)
md-viewer start

# Custom host and port
md-viewer start --host 0.0.0.0 --port 8080

# Debug mode
md-viewer start --debug
```

## Project Structure

```
Md_File_Reader/
├── md_viewer/              # Main package
│   ├── __init__.py        # Version and package info
│   ├── app.py             # Flask application
│   ├── cli.py             # Command-line interface
│   └── templates/         # HTML templates
├── markdown_files/        # Your markdown documents
├── doc/                   # Project documentation
│   ├── USER_GUIDE.md     # Complete user guide
│   ├── CHANGELOG.md      # Release history
│   └── VERSION.md        # Version management
├── setup.py              # Package setup (PEP 517)
├── run.py                # Direct launcher
├── start.bat             # Windows startup
└── requirements.txt      # Dependencies
```

## Documentation

- **Quick Reference**: This README
- **Complete Guide**: [doc/USER_GUIDE.md](doc/USER_GUIDE.md)
- **Online**: http://localhost:8000/docs (when server is running)
- **Changelog**: [doc/CHANGELOG.md](doc/CHANGELOG.md)
- **Version Info**: [doc/VERSION.md](doc/VERSION.md)
├── templates/
│   └── index.html        # HTML template
├── markdown_files/       # Place your .md files here
└── README.md            # This file
```

## Configuration

You can modify these settings in `app.py`:

- `MD_FOLDER`: Change the folder path where markdown files are stored (default: `'markdown_files'`)
- `ALLOWED_EXTENSIONS`: Modify allowed file extensions (default: `{'.md', '.markdown'}`)
- Host and port settings in `app.run()` (default: `host='0.0.0.0', port=5000`)

## Example Markdown Files

Create sample markdown files in the `markdown_files` folder:

**example.md:**
```markdown
# Welcome to My Documentation

This is a sample markdown file.

## Features

- Easy to use
- Beautiful formatting
- Code highlighting

## Code Example

```python
def hello_world():
    print("Hello, World!")
```

## Table Example

| Feature | Status |
|---------|--------|
| Markdown | ✅ |
| HTML | ✅ |
```

## Supported Markdown Extensions

- **Fenced Code Blocks**: Syntax-highlighted code blocks
- **Tables**: Full table support with styling
- **New Line to Break**: Automatic line breaks
- **Sane Lists**: Better list handling
- **CodeHilite**: Code syntax highlighting
- **Table of Contents**: Automatic TOC generation

## Customization

The design can be customized by editing the CSS in `templates/index.html`. The current theme features:

- Purple gradient background
- White content cards with shadow effects
- Syntax highlighting for code blocks
- Responsive design for mobile devices

## 🛠️ Development

DocPresent follows industry best practices and standards used by top open-source Python projects.

### Quick Setup
```bash
# Clone and setup
git clone <repository-url>
cd Md_File_Reader
python -m venv .venv
.venv\Scripts\activate  # Windows
source .venv/bin/activate  # Linux/Mac

# Install dependencies
pip install -r requirements.txt -r requirements-dev.txt

# Install pre-commit hooks
pre-commit install

# Run tests
pytest --cov=doc_viewer

# Format code
black doc_viewer/
isort doc_viewer/
```

### Code Quality Tools
- ✅ **Black** - Code formatting (100 char lines)
- ✅ **Flake8** - Linting and style checking
- ✅ **isort** - Import sorting
- ✅ **mypy** - Type checking
- ✅ **pytest** - Testing framework with coverage
- ✅ **pre-commit** - Git hooks for quality gates

### CI/CD
- ✅ GitHub Actions for automated testing
- ✅ Multi-OS testing (Windows, macOS, Linux)
- ✅ Multi-Python testing (3.8, 3.9, 3.10, 3.11, 3.12)
- ✅ Automated releases with executables
- ✅ Code coverage reporting

### Contributing
See [CONTRIBUTING.md](CONTRIBUTING.md) for:
- Code style guidelines
- Commit message conventions
- Pull request process
- Testing requirements

### Documentation
- **User Guide**: `doc/USER_GUIDE.md`
- **Quick Start**: `doc/QUICKSTART.md`
- **Build Guide**: `doc/BUILD.md`
- **Open Source Standards**: `doc/OPEN_SOURCE_STANDARDS.md`
- **Changelog**: `doc/CHANGELOG.md`

## 📜 License

**Cisco Internal Use Only**

This software is proprietary to Cisco Systems, Inc. and licensed for internal use within Cisco enterprise only. See [LICENSE](LICENSE) file for complete terms.

- ✅ Use within Cisco environment
- ✅ Modify for internal Cisco needs  
- ❌ External distribution prohibited
- ❌ Not for customer or partner use

**Contact:** Suresh Kumar (sureshk6@cisco.com)  
**Copyright:** © 2025 Cisco Systems, Inc. All Rights Reserved.
