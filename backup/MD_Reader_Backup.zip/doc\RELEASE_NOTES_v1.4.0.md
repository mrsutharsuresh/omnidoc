# DocPresent v1.4.0 - Release Notes

**Release Date:** December 24, 2025  
**Version:** 1.4.0  
**Status:** Production Ready ✅

---

## 🎉 Overview

DocPresent v1.4.0 is a major feature release that transforms the platform into a comprehensive document management and editing solution. This release adds 8 powerful new capabilities including Word document support, in-browser editing, advanced workspace management, and enhanced user experience improvements.

---

## ✨ New Features

### 1. **Word Document Input Support** 📄

DocPresent now accepts Microsoft Word (.docx) files as input alongside Markdown documents:

- **Automatic Conversion**: Word documents are converted to HTML using the mammoth library
- **Real-time Rendering**: Seamless display with existing viewer features
- **Multi-format Support**: Browse and Preview modes work with both .md and .docx files
- **View-Only Mode**: Edit button disabled for Word documents (preserves original format)

**How to Use:**
- Click "Browse Files" and select a .docx file
- Or use the Preview/Upload button to drag & drop Word documents
- Documents render instantly with formatting preserved

### 2. **In-Browser Document Editor** ✏️

Edit Markdown and text files directly in the browser with Monaco Editor:

- **Professional Editor**: Same editor used in VS Code
- **Syntax Highlighting**: Markdown-specific syntax coloring
- **Auto-Save Backup**: Creates .bak files before saving changes
- **Live Preview**: Save and reload to see changes immediately
- **Security Validated**: Prevents unsafe file operations

**How to Use:**
1. Open any .md or .txt file
2. Click the ✏️ Edit button in the navigation bar
3. Make changes in the Monaco editor
4. Click "Save Changes" to persist edits
5. Click "Cancel" or "Edit" again to close editor

**Important:** Editor appears only for Markdown/text files. Word documents are view-only.

### 3. **User Log Collection System** 📋

Comprehensive logging system for debugging and issue reporting:

- **Rotating Logs**: 10 MB per file, 7 backup files retained
- **One-Click Download**: 📋 button in navigation bar
- **Automatic Sanitization**: Removes IP addresses and sensitive paths
- **ZIP Archive**: Easy to share with developers
- **Comprehensive Tracking**: All operations, errors, and warnings logged

**How to Use:**
1. Click the 📋 button in the top navigation bar
2. logs.zip downloads automatically
3. Extract and review log files
4. Share with support when reporting issues

**Log Location:** `logs/docpresent.log` in application directory

### 4. **Clickable Document Links** 🔗

All links in rendered documents are now fully functional:

- **External Links**: Open in new tabs automatically
- **Internal Anchors**: Smooth scroll to document sections
- **Relative Links**: Navigate to other files in workspace
- **Broken Link Detection**: Visual indicators for invalid links
- **Word Document Links**: Preserved from original .docx files

**Supported Link Types:**
- `http://`, `https://` - External websites
- `#section` - Internal document anchors
- `./file.md`, `../doc/file.md` - Relative file paths

### 5. **Relative Link Resolution** 🧭

Intelligent context-aware link resolution:

- **Browse Mode**: Links resolve relative to file location
- **Preview Mode**: Session-based base path tracking
- **Nested Documents**: Correct resolution in subdirectories
- **Context Preservation**: Base path maintained when switching files

**Technical Details:**
- Session storage tracks preview file base paths
- JavaScript link handlers resolve paths dynamically
- Server-side validation prevents directory traversal

### 6. **Custom Workspace Selection** 📁

Manage multiple document workspaces with ease:

**Features:**
- **Prominent Workspace Section**: Large, visible selector below hero section
- **Browse Button**: Modern File System Access API integration (📂)
- **Multiple Workspaces**: Add, switch, and manage document folders
- **Persistent Configuration**: Settings saved in config.json
- **Security Validation**: Blocks system directories (Windows, Program Files)
- **Delete Functionality**: Remove workspaces with confirmation

**How to Use:**
1. Look for the "Active Workspace" section below the hero banner
2. Click "Change Workspace" button
3. Click "📂 Browse" to select a folder (or enter path manually)
4. Click "Add Workspace" to save
5. Click "Activate" on any workspace to switch
6. Click 🗑️ to delete unwanted workspaces

**Manual Folder Entry:**
If browser doesn't support folder picker, manually enter path:
- Windows: `C:\Users\YourName\Documents`
- Linux/Mac: `/home/yourname/documents`

### 7. **PDF Export Auto-Installation** 🔧

Automatic wkhtmltopdf installation eliminates PDF export setup friction:

- **One-Click Install**: Detects missing wkhtmltopdf and offers installation
- **No Admin Rights**: Portable installation (54 MB download)
- **Progress Dialog**: Real-time status updates during installation
- **Graceful Fallback**: Manual installation instructions if auto-install fails
- **PATH Detection**: Finds existing installations automatically

**How to Use:**
1. Click "Export" → "PDF" from document viewer
2. If wkhtmltopdf is missing, installation dialog appears
3. Click "Install Now"
4. Wait for download and extraction (30-60 seconds)
5. PDF export works automatically after installation

**Manual Installation:**
If auto-install fails, download from: https://wkhtmltopdf.org/downloads.html

### 8. **Enhanced UX Improvements** 🎨

Multiple user experience refinements:

- **Prominent Workspace Display**: Large bordered card shows current workspace
- **Browse Button Integration**: Easy folder selection with fallback
- **Edit Button Reliability**: Fixed null reference errors
- **Syntax Error Resolution**: Removed duplicate JavaScript braces
- **Improved Modal Design**: Better workspace management UI
- **Enhanced Navigation**: Clearer button labels and tooltips

---

## 🔧 Technical Details

### New API Endpoints

```
GET  /api/get-source/<path>          - Retrieve file content for editing
POST /api/save-document              - Save edited document with backup
GET  /api/download-logs              - Download sanitized logs as ZIP
GET  /api/workspaces                 - List all configured workspaces
POST /api/workspaces                 - Add new workspace
POST /api/workspaces/active          - Switch active workspace
DELETE /api/workspaces/<path>        - Remove workspace
POST /api/install-wkhtmltopdf        - Install PDF export dependencies
```

### New Dependencies

```
mammoth>=1.6.0           - Word document conversion
html2text>=2020.1.16     - HTML to Markdown conversion
lxml>=4.9.0              - Fast HTML parsing
```

### Helper Functions

- `convert_docx_to_html()` - Word to HTML conversion
- `process_links_in_html()` - Link detection and processing
- `is_safe_workspace()` - Security validation for paths
- `sanitize_log_content()` - Remove sensitive data from logs
- `find_wkhtmltopdf()` - Search for wkhtmltopdf executable
- `install_wkhtmltopdf_portable()` - Download and install portable version

### Frontend Enhancements

- **Monaco Editor 0.45.0**: CDN integration for code editing
- **File System Access API**: Modern browser folder picker
- **Enhanced Modals**: Workspace and PDF installation dialogs
- **Dynamic UI**: Edit mode toggle with save/cancel controls
- **Responsive Design**: Mobile-friendly workspace selector

---

## 🐛 Bug Fixes

### Critical Fixes

1. **Editor Button Functionality**
   - Fixed null reference errors when toggling edit mode
   - Added proper null checks for editor and document containers
   - Corrected initial state detection (empty string vs 'none')

2. **Syntax Errors**
   - Removed duplicate closing brace in view.html (line 975)
   - Fixed JavaScript parsing issues

3. **Workspace Selector UX**
   - Made workspace section highly visible below hero section
   - Added large bordered card design showing current workspace path
   - Implemented browse button for easier folder selection
   - Fixed workspace switching to properly override Sample folder

### Minor Fixes

4. **PDF Export Reliability**
   - Fixed "wkhtmltopdf not found" errors on fresh installations
   - Better error messages with installation guidance

5. **Link Navigation**
   - Fixed broken relative links in Browse mode
   - Corrected link resolution for uploaded/preview files
   - Maintained link context when switching documents

---

## 📦 Installation & Upgrade

### New Installation

1. Download `DocPresent_v1.4.0.exe` from releases
2. Run the executable (no installation required)
3. Application opens at http://localhost:8000
4. Click "Change Workspace" to set your document folder
5. Start viewing and editing documents

### Upgrading from v1.0.0-v1.3.x

1. Close running DocPresent application
2. Replace old .exe with new `DocPresent_v1.4.0.exe`
3. Run the new executable
4. Existing workspaces are preserved in config.json
5. New features available immediately

**Data Migration:**
- Workspaces: config.json is preserved (no action needed)
- Logs: Old logs remain in logs/ folder
- Settings: All preferences carried forward

---

## 🧪 Testing

### Automated Testing

All 23 unit tests pass:
```powershell
pytest tests/test_app.py -v
# Result: 23 passed in 1.59s
```

Tests cover:
- ✅ Workspace management API
- ✅ Log download functionality
- ✅ Word document support
- ✅ Editor endpoints
- ✅ Version validation
- ✅ Security checks
- ✅ Full workflow integration

### Manual Testing

Interactive test script with 35+ test cases:
```powershell
.\tests\test_manual.ps1
```

Covers:
- Word document upload and rendering
- In-browser editing and saving
- Log collection and sanitization
- Clickable links (external, internal, relative)
- Workspace management (add, switch, delete, browse)
- PDF auto-installation
- Regression tests for existing features

---

## 📚 Documentation

### Updated Documentation

- **CHANGELOG.md**: Comprehensive v1.4.0 changes
- **USER_GUIDE.md**: Updated with new features
- **BUILD.md**: Updated build process for new dependencies
- **DEPLOYMENT_CHECKLIST.md**: v1.4.0 release checklist

### New Test Documentation

- **tests/test_app.py**: 23 automated tests with comprehensive coverage
- **tests/test_manual.ps1**: Interactive manual testing script

---

## 🔒 Security Considerations

### Workspace Security

- **Path Validation**: Blocks system directories (C:\Windows, C:\Program Files)
- **Directory Traversal**: Prevents ../ path escapes
- **Whitelist Approach**: Only allows user-specified workspace folders

### Editor Security

- **File Operation Validation**: Prevents writing outside workspace
- **Backup Creation**: .bak files created before any modification
- **Input Sanitization**: Content validated before saving

### Log Security

- **Automatic Sanitization**: IP addresses and full paths removed
- **Redaction Patterns**: Sensitive data replaced with placeholders
- **Secure Storage**: Logs stored in application directory only

---

## ⚠️ Known Issues

### Browser Compatibility

1. **File System Access API**
   - Not supported in Firefox (manual path entry fallback works)
   - Safari has limited support (manual entry recommended)
   - Chrome/Edge: Full support for browse button

2. **Monaco Editor**
   - Requires internet connection (CDN-based)
   - Offline mode: Editor loads with limited features

### Platform Limitations

3. **Word Document Editing**
   - View-only mode for .docx files
   - Edit button intentionally disabled
   - Use Microsoft Word for editing, DocPresent for viewing

4. **PDF Export**
   - Auto-installation downloads 54 MB (requires internet)
   - First PDF export may be slow (wkhtmltopdf initialization)

---

## 🚀 Performance

### Load Times

- **Markdown Rendering**: < 100ms for documents up to 1 MB
- **Word Document Conversion**: 200-500ms for typical .docx files
- **Monaco Editor Load**: 500-1000ms (CDN download, cached after first load)
- **PDF Export**: 1-3 seconds per page

### Resource Usage

- **Memory**: 80-150 MB typical usage
- **Disk Space**: 150 MB (application + dependencies + logs)
- **Network**: CDN requests for Monaco Editor (one-time per session)

---

## 🎯 Roadmap

### Planned for v1.5.0

- **Offline Monaco Editor**: Bundled editor for air-gapped environments
- **Word Document Editing**: Round-trip .docx editing with format preservation
- **Collaborative Editing**: Multi-user real-time editing
- **Git Integration**: Version control for documents

### Under Consideration

- **Export to Word**: Convert Markdown to .docx
- **Dark Mode Improvements**: Enhanced theme system
- **Plugin Architecture**: User-extensible features
- **Cloud Workspace**: Remote document storage integration

---

## 👥 Contributors

- **Suresh K6**: Lead Developer, Feature Implementation
- **GitHub Copilot**: Code assistance, testing infrastructure
- **Community**: Bug reports and feature requests

---

## 📄 License

MIT License - See LICENSE file for details

---

## 🆘 Support

### Getting Help

- **Issues**: https://github.com/yourusername/DocPresent/issues
- **Documentation**: See doc/ folder for comprehensive guides
- **Logs**: Use 📋 button to download logs for bug reports

### Reporting Bugs

1. Click 📋 to download logs
2. Create GitHub issue with:
   - Steps to reproduce
   - Expected vs actual behavior
   - Attached logs.zip
   - DocPresent version (v1.4.0)
   - Operating system details

---

## 🙏 Acknowledgments

- **mammoth**: Excellent Word document conversion library
- **Monaco Editor**: Microsoft's powerful browser-based editor
- **Flask**: Robust web framework for Python
- **pytest**: Comprehensive testing framework

---

**Happy Documenting! 📝✨**

For detailed technical information, see [CHANGELOG.md](CHANGELOG.md)
For upgrade instructions, see [DEPLOYMENT_CHECKLIST.md](DEPLOYMENT_CHECKLIST.md)
